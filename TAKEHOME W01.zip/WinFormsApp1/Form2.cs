﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form2 : Form
    {
        public List<string> katarnd2;
        string guess;
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            Random random = new Random();
            int acak = random.Next(katarnd2.Count);
            guess = katarnd2[acak];
        }

        private void bt_q_Click(object sender, EventArgs e)
        {
            huruf('q');
        }

      

        private void bt_w_Click(object sender, EventArgs e)
        {
            huruf('w');
        }

        private void bt_e_Click(object sender, EventArgs e)
        {
            huruf('e');
        }

        private void bt_r_Click(object sender, EventArgs e)
        {
            huruf('r');
        }

        private void bt_t_Click(object sender, EventArgs e)
        {
            huruf('t');
        }

        private void bt_y_Click(object sender, EventArgs e)
        {
            huruf('y');
        }

        private void bt_i_Click(object sender, EventArgs e)
        {
            huruf('i');
        }

        private void bt_o_Click(object sender, EventArgs e)
        {
            huruf('o');
        }

        private void bt_p_Click(object sender, EventArgs e)
        {
            huruf('p');
        }

        private void bt_a_Click(object sender, EventArgs e)
        {
            huruf('a');
        }

        private void bt_s_Click(object sender, EventArgs e)
        {
            huruf('s');
        }

        private void bt_d_Click(object sender, EventArgs e)
        {
            huruf('d');
        }

        private void bt_f_Click(object sender, EventArgs e)
        {
            huruf('f');
        }

        private void bt_g_Click(object sender, EventArgs e)
        {
            huruf('g');
        }

        private void bt_h_Click(object sender, EventArgs e)
        {
            huruf('h');
        }

        private void bt_j_Click(object sender, EventArgs e)
        {
            huruf('j');
        }

        private void bt_k_Click(object sender, EventArgs e)
        {
            huruf('k');
        }

        private void bt_l_Click(object sender, EventArgs e)
        {
            huruf('l');
        }

        private void bt_z_Click(object sender, EventArgs e)
        {
            huruf('z');
        }

        private void bt_x_Click(object sender, EventArgs e)
        {
            huruf('x');
        }

        private void bt_c_Click(object sender, EventArgs e)
        {
            huruf('c');
        }

        private void bt_v_Click(object sender, EventArgs e)
        {
            huruf('v');
        }

        private void bt_b_Click(object sender, EventArgs e)
        {
            huruf('b');
        }

        private void bt_n_Click(object sender, EventArgs e)
        {
            huruf('n');
        }

        private void bt_m_Click(object sender, EventArgs e)
        {
            huruf('m');
        }

        private void bt_u_Click(object sender, EventArgs e)
        {
            huruf('u');
        }

        private void huruf(char a)
        {
            for (int i = 0; i < 5; i++)
            {
                if (a == guess[i])
                {
                    if (i== 0)
                    {
                        lbl_1.Text = a.ToString();
                    }
                    if (i == 1)
                    {
                        lbl_2.Text = a.ToString();
                    }
                    if (i == 2)
                    {
                        lbl_3.Text = a.ToString();
                    }
                    if (i == 3)
                    {
                        lbl_4.Text = a.ToString();
                    }
                    if (i == 4)
                    {
                        lbl_5.Text = a.ToString();
                    }
                    result();
                }
            }
        }

        private void result()
        {
            string hasil = "";
            hasil = lbl_1.Text + lbl_2.Text + lbl_3.Text + lbl_4.Text + lbl_5.Text;
            if (hasil == guess)
            {
                MessageBox.Show("Congratulation");
            }
            
        }



    }
}
