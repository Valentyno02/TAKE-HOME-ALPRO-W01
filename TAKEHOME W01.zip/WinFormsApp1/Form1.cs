namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void bt_CEK_Click(object sender, EventArgs e)
        {
            List<string> gamekata = new List<string>();
            

            if (tb_1.Text != "" && tb_1.Text != "" && tb_3.Text != "" && tb_4.Text != "" && tb_5.Text != "")
            {

                if (tb_1.Text.Length == 5)
                {
                    gamekata.Add(tb_1.Text);
                }
                else
                {
                    MessageBox.Show("kata 1 harus 5 huruf");
                }
                if (tb_2.Text.Length == 5)
                {
                    gamekata.Add(tb_2.Text);
                }
                else
                {
                    MessageBox.Show("kata 2 harus 5 huruf");
                }
                if (tb_3.Text.Length == 5)
                {
                    gamekata.Add(tb_3.Text);
                }
                else
                {
                    MessageBox.Show("kata 3 harus 5 huruf");
                }
                if (tb_4.Text.Length == 5)
                {
                    gamekata.Add(tb_4.Text);
                }
                else
                {
                    MessageBox.Show("kata 4 harus 5 huruf");
                }
                if (tb_5.Text.Length == 5)
                {
                    gamekata.Add(tb_5.Text);
                }
                else
                {
                    MessageBox.Show("kata 5 harus 5 huruf");
                }
            }
            else
            {
                MessageBox.Show("pastikan semua kata terisi");
            }

            List <string> katarnd = new List<string>();
            katarnd.Add(gamekata[0]);
           
            for (int i = 1; i < gamekata.Count; i++)
            {
                int counter = 0;
                for (int j = 0; j < katarnd.Count; j++)
                {
                    if (katarnd[j] == gamekata[i])
                    {
                        counter++;
                    }
                    if (counter >= 1)
                    {
                        MessageBox.Show("kata tidak boleh sama");
                    }
                }
                if (counter == 0)
                {
                    katarnd.Add(gamekata[i]);
                }
            }

            bool cekangka = true;
            foreach (string x in katarnd)
            {
                foreach (char y in x)
                {
                    if (char.IsDigit(y))
                    {
                        cekangka = false;
                        MessageBox.Show("tidak boleh ada angka");
                    }
                }
            }

            if (cekangka == true && katarnd.Count == 5)
            {
                Form2 papan = new Form2();
                papan.katarnd2 = katarnd;
                papan.ShowDialog();
            }
            




        }
    }
}