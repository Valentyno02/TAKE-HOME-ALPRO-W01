﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            bt_CEK = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            tb_1 = new TextBox();
            tb_2 = new TextBox();
            tb_4 = new TextBox();
            tb_3 = new TextBox();
            tb_5 = new TextBox();
            SuspendLayout();
            // 
            // bt_CEK
            // 
            bt_CEK.Location = new Point(101, 265);
            bt_CEK.Name = "bt_CEK";
            bt_CEK.Size = new Size(96, 28);
            bt_CEK.TabIndex = 0;
            bt_CEK.Text = "CEK";
            bt_CEK.UseVisualStyleBackColor = true;
            bt_CEK.Click += bt_CEK_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(24, 65);
            label1.Name = "label1";
            label1.Size = new Size(56, 20);
            label1.TabIndex = 1;
            label1.Text = "KATA 1";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(24, 101);
            label2.Name = "label2";
            label2.Size = new Size(56, 20);
            label2.TabIndex = 2;
            label2.Text = "KATA 2";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(24, 214);
            label3.Name = "label3";
            label3.Size = new Size(56, 20);
            label3.TabIndex = 3;
            label3.Text = "KATA 5";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(24, 177);
            label4.Name = "label4";
            label4.Size = new Size(56, 20);
            label4.TabIndex = 4;
            label4.Text = "KATA 4";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(24, 138);
            label5.Name = "label5";
            label5.Size = new Size(56, 20);
            label5.TabIndex = 5;
            label5.Text = "KATA 3";
            // 
            // tb_1
            // 
            tb_1.Location = new Point(101, 59);
            tb_1.Name = "tb_1";
            tb_1.Size = new Size(118, 27);
            tb_1.TabIndex = 6;
            // 
            // tb_2
            // 
            tb_2.Location = new Point(101, 101);
            tb_2.Name = "tb_2";
            tb_2.Size = new Size(118, 27);
            tb_2.TabIndex = 7;
            // 
            // tb_4
            // 
            tb_4.Location = new Point(101, 177);
            tb_4.Name = "tb_4";
            tb_4.Size = new Size(118, 27);
            tb_4.TabIndex = 8;
            tb_4.TextChanged += textBox3_TextChanged;
            // 
            // tb_3
            // 
            tb_3.Location = new Point(101, 138);
            tb_3.Name = "tb_3";
            tb_3.Size = new Size(118, 27);
            tb_3.TabIndex = 9;
            // 
            // tb_5
            // 
            tb_5.Location = new Point(101, 214);
            tb_5.Name = "tb_5";
            tb_5.Size = new Size(118, 27);
            tb_5.TabIndex = 10;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(tb_5);
            Controls.Add(tb_3);
            Controls.Add(tb_4);
            Controls.Add(tb_2);
            Controls.Add(tb_1);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(bt_CEK);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button bt_CEK;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private TextBox tb_1;
        private TextBox tb_2;
        private TextBox tb_4;
        private TextBox tb_3;
        private TextBox tb_5;
    }
}