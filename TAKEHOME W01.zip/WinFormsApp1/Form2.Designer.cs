﻿namespace WinFormsApp1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            bt_q = new Button();
            bt_f = new Button();
            bt_d = new Button();
            bt_s = new Button();
            bt_a = new Button();
            bt_p = new Button();
            bt_o = new Button();
            bt_i = new Button();
            bt_u = new Button();
            bt_y = new Button();
            bt_t = new Button();
            bt_r = new Button();
            bt_e = new Button();
            bt_w = new Button();
            bt_h = new Button();
            bt_k = new Button();
            bt_l = new Button();
            bt_j = new Button();
            bt_b = new Button();
            bt_g = new Button();
            bt_v = new Button();
            bt_c = new Button();
            bt_x = new Button();
            bt_z = new Button();
            bt_m = new Button();
            bt_n = new Button();
            lbl_1 = new Label();
            lbl_2 = new Label();
            lbl_5 = new Label();
            lbl_4 = new Label();
            lbl_3 = new Label();
            SuspendLayout();
            // 
            // bt_q
            // 
            bt_q.Location = new Point(95, 185);
            bt_q.Name = "bt_q";
            bt_q.Size = new Size(55, 50);
            bt_q.TabIndex = 0;
            bt_q.Text = "Q";
            bt_q.UseVisualStyleBackColor = true;
            bt_q.Click += bt_q_Click;
            // 
            // bt_f
            // 
            bt_f.Location = new Point(311, 241);
            bt_f.Name = "bt_f";
            bt_f.Size = new Size(55, 50);
            bt_f.TabIndex = 1;
            bt_f.Text = "F";
            bt_f.UseVisualStyleBackColor = true;
            bt_f.Click += bt_f_Click;
            // 
            // bt_d
            // 
            bt_d.Location = new Point(250, 241);
            bt_d.Name = "bt_d";
            bt_d.Size = new Size(55, 50);
            bt_d.TabIndex = 2;
            bt_d.Text = "D";
            bt_d.UseVisualStyleBackColor = true;
            bt_d.Click += bt_d_Click;
            // 
            // bt_s
            // 
            bt_s.Location = new Point(189, 241);
            bt_s.Name = "bt_s";
            bt_s.Size = new Size(55, 50);
            bt_s.TabIndex = 3;
            bt_s.Text = "S";
            bt_s.UseVisualStyleBackColor = true;
            bt_s.Click += bt_s_Click;
            // 
            // bt_a
            // 
            bt_a.Location = new Point(128, 241);
            bt_a.Name = "bt_a";
            bt_a.Size = new Size(55, 50);
            bt_a.TabIndex = 4;
            bt_a.Text = "A";
            bt_a.UseVisualStyleBackColor = true;
            bt_a.Click += bt_a_Click;
            // 
            // bt_p
            // 
            bt_p.Location = new Point(644, 185);
            bt_p.Name = "bt_p";
            bt_p.Size = new Size(55, 50);
            bt_p.TabIndex = 5;
            bt_p.Text = "P";
            bt_p.UseVisualStyleBackColor = true;
            bt_p.Click += bt_p_Click;
            // 
            // bt_o
            // 
            bt_o.Location = new Point(583, 185);
            bt_o.Name = "bt_o";
            bt_o.Size = new Size(55, 50);
            bt_o.TabIndex = 6;
            bt_o.Text = "O";
            bt_o.UseVisualStyleBackColor = true;
            bt_o.Click += bt_o_Click;
            // 
            // bt_i
            // 
            bt_i.Location = new Point(522, 185);
            bt_i.Name = "bt_i";
            bt_i.Size = new Size(55, 50);
            bt_i.TabIndex = 7;
            bt_i.Text = "I";
            bt_i.UseVisualStyleBackColor = true;
            bt_i.Click += bt_i_Click;
            // 
            // bt_u
            // 
            bt_u.Location = new Point(461, 185);
            bt_u.Name = "bt_u";
            bt_u.Size = new Size(55, 50);
            bt_u.TabIndex = 8;
            bt_u.Text = "U";
            bt_u.UseVisualStyleBackColor = true;
            bt_u.Click += bt_u_Click;
            // 
            // bt_y
            // 
            bt_y.Location = new Point(400, 185);
            bt_y.Name = "bt_y";
            bt_y.Size = new Size(55, 50);
            bt_y.TabIndex = 9;
            bt_y.Text = "Y";
            bt_y.UseVisualStyleBackColor = true;
            bt_y.Click += bt_y_Click;
            // 
            // bt_t
            // 
            bt_t.Location = new Point(339, 185);
            bt_t.Name = "bt_t";
            bt_t.Size = new Size(55, 50);
            bt_t.TabIndex = 10;
            bt_t.Text = "T";
            bt_t.UseVisualStyleBackColor = true;
            bt_t.Click += bt_t_Click;
            // 
            // bt_r
            // 
            bt_r.Location = new Point(278, 185);
            bt_r.Name = "bt_r";
            bt_r.Size = new Size(55, 50);
            bt_r.TabIndex = 11;
            bt_r.Text = "R";
            bt_r.UseVisualStyleBackColor = true;
            bt_r.Click += bt_r_Click;
            // 
            // bt_e
            // 
            bt_e.Location = new Point(217, 185);
            bt_e.Name = "bt_e";
            bt_e.Size = new Size(55, 50);
            bt_e.TabIndex = 12;
            bt_e.Text = "E";
            bt_e.UseVisualStyleBackColor = true;
            bt_e.Click += bt_e_Click;
            // 
            // bt_w
            // 
            bt_w.Location = new Point(156, 185);
            bt_w.Name = "bt_w";
            bt_w.Size = new Size(55, 50);
            bt_w.TabIndex = 13;
            bt_w.Text = "W";
            bt_w.UseVisualStyleBackColor = true;
            bt_w.Click += bt_w_Click;
            // 
            // bt_h
            // 
            bt_h.Location = new Point(433, 241);
            bt_h.Name = "bt_h";
            bt_h.Size = new Size(55, 50);
            bt_h.TabIndex = 14;
            bt_h.Text = "H";
            bt_h.UseVisualStyleBackColor = true;
            bt_h.Click += bt_h_Click;
            // 
            // bt_k
            // 
            bt_k.Location = new Point(555, 241);
            bt_k.Name = "bt_k";
            bt_k.Size = new Size(55, 50);
            bt_k.TabIndex = 15;
            bt_k.Text = "K";
            bt_k.UseVisualStyleBackColor = true;
            bt_k.Click += bt_k_Click;
            // 
            // bt_l
            // 
            bt_l.Location = new Point(616, 241);
            bt_l.Name = "bt_l";
            bt_l.Size = new Size(55, 50);
            bt_l.TabIndex = 16;
            bt_l.Text = "L";
            bt_l.UseVisualStyleBackColor = true;
            bt_l.Click += bt_l_Click;
            // 
            // bt_j
            // 
            bt_j.Location = new Point(494, 241);
            bt_j.Name = "bt_j";
            bt_j.Size = new Size(55, 50);
            bt_j.TabIndex = 17;
            bt_j.Text = "J";
            bt_j.UseVisualStyleBackColor = true;
            bt_j.Click += bt_j_Click;
            // 
            // bt_b
            // 
            bt_b.Location = new Point(400, 300);
            bt_b.Name = "bt_b";
            bt_b.Size = new Size(55, 50);
            bt_b.TabIndex = 18;
            bt_b.Text = "B";
            bt_b.UseVisualStyleBackColor = true;
            bt_b.Click += bt_b_Click;
            // 
            // bt_g
            // 
            bt_g.Location = new Point(372, 241);
            bt_g.Name = "bt_g";
            bt_g.Size = new Size(55, 50);
            bt_g.TabIndex = 19;
            bt_g.Text = "G";
            bt_g.UseVisualStyleBackColor = true;
            bt_g.Click += bt_g_Click;
            // 
            // bt_v
            // 
            bt_v.Location = new Point(339, 297);
            bt_v.Name = "bt_v";
            bt_v.Size = new Size(55, 50);
            bt_v.TabIndex = 20;
            bt_v.Text = "V";
            bt_v.UseVisualStyleBackColor = true;
            bt_v.Click += bt_v_Click;
            // 
            // bt_c
            // 
            bt_c.Location = new Point(278, 297);
            bt_c.Name = "bt_c";
            bt_c.Size = new Size(55, 50);
            bt_c.TabIndex = 21;
            bt_c.Text = "C";
            bt_c.UseVisualStyleBackColor = true;
            bt_c.Click += bt_c_Click;
            // 
            // bt_x
            // 
            bt_x.Location = new Point(217, 297);
            bt_x.Name = "bt_x";
            bt_x.Size = new Size(55, 50);
            bt_x.TabIndex = 22;
            bt_x.Text = "X";
            bt_x.UseVisualStyleBackColor = true;
            bt_x.Click += bt_x_Click;
            // 
            // bt_z
            // 
            bt_z.Location = new Point(156, 297);
            bt_z.Name = "bt_z";
            bt_z.Size = new Size(55, 50);
            bt_z.TabIndex = 23;
            bt_z.Text = "Z";
            bt_z.UseVisualStyleBackColor = true;
            bt_z.Click += bt_z_Click;
            // 
            // bt_m
            // 
            bt_m.Location = new Point(522, 300);
            bt_m.Name = "bt_m";
            bt_m.Size = new Size(55, 50);
            bt_m.TabIndex = 26;
            bt_m.Text = "M";
            bt_m.UseVisualStyleBackColor = true;
            bt_m.Click += bt_m_Click;
            // 
            // bt_n
            // 
            bt_n.Location = new Point(461, 300);
            bt_n.Name = "bt_n";
            bt_n.Size = new Size(55, 50);
            bt_n.TabIndex = 27;
            bt_n.Text = "N";
            bt_n.UseVisualStyleBackColor = true;
            bt_n.Click += bt_n_Click;
            // 
            // lbl_1
            // 
            lbl_1.AutoSize = true;
            lbl_1.Font = new Font("Segoe UI", 36F, FontStyle.Regular, GraphicsUnit.Point);
            lbl_1.Location = new Point(189, 81);
            lbl_1.Name = "lbl_1";
            lbl_1.Size = new Size(60, 81);
            lbl_1.TabIndex = 28;
            lbl_1.Text = "_";
            // 
            // lbl_2
            // 
            lbl_2.AutoSize = true;
            lbl_2.Font = new Font("Segoe UI", 36F, FontStyle.Regular, GraphicsUnit.Point);
            lbl_2.Location = new Point(273, 81);
            lbl_2.Name = "lbl_2";
            lbl_2.Size = new Size(60, 81);
            lbl_2.TabIndex = 29;
            lbl_2.Text = "_";
            // 
            // lbl_5
            // 
            lbl_5.AutoSize = true;
            lbl_5.Font = new Font("Segoe UI", 36F, FontStyle.Regular, GraphicsUnit.Point);
            lbl_5.Location = new Point(522, 81);
            lbl_5.Name = "lbl_5";
            lbl_5.Size = new Size(60, 81);
            lbl_5.TabIndex = 30;
            lbl_5.Text = "_";
            // 
            // lbl_4
            // 
            lbl_4.AutoSize = true;
            lbl_4.Font = new Font("Segoe UI", 36F, FontStyle.Regular, GraphicsUnit.Point);
            lbl_4.Location = new Point(433, 81);
            lbl_4.Name = "lbl_4";
            lbl_4.Size = new Size(60, 81);
            lbl_4.TabIndex = 31;
            lbl_4.Text = "_";
            // 
            // lbl_3
            // 
            lbl_3.AutoSize = true;
            lbl_3.Font = new Font("Segoe UI", 36F, FontStyle.Regular, GraphicsUnit.Point);
            lbl_3.Location = new Point(356, 81);
            lbl_3.Name = "lbl_3";
            lbl_3.Size = new Size(60, 81);
            lbl_3.TabIndex = 32;
            lbl_3.Text = "_";
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lbl_3);
            Controls.Add(lbl_4);
            Controls.Add(lbl_5);
            Controls.Add(lbl_2);
            Controls.Add(lbl_1);
            Controls.Add(bt_n);
            Controls.Add(bt_m);
            Controls.Add(bt_z);
            Controls.Add(bt_x);
            Controls.Add(bt_c);
            Controls.Add(bt_v);
            Controls.Add(bt_g);
            Controls.Add(bt_b);
            Controls.Add(bt_j);
            Controls.Add(bt_l);
            Controls.Add(bt_k);
            Controls.Add(bt_h);
            Controls.Add(bt_w);
            Controls.Add(bt_e);
            Controls.Add(bt_r);
            Controls.Add(bt_t);
            Controls.Add(bt_y);
            Controls.Add(bt_u);
            Controls.Add(bt_i);
            Controls.Add(bt_o);
            Controls.Add(bt_p);
            Controls.Add(bt_a);
            Controls.Add(bt_s);
            Controls.Add(bt_d);
            Controls.Add(bt_f);
            Controls.Add(bt_q);
            Name = "Form2";
            Text = "Form2";
            Load += Form2_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button bt_q;
        private Button bt_f;
        private Button bt_d;
        private Button bt_s;
        private Button bt_a;
        private Button bt_p;
        private Button bt_o;
        private Button bt_i;
        private Button bt_u;
        private Button bt_y;
        private Button bt_t;
        private Button bt_r;
        private Button bt_e;
        private Button bt_w;
        private Button bt_h;
        private Button bt_k;
        private Button bt_l;
        private Button bt_j;
        private Button bt_b;
        private Button bt_g;
        private Button bt_v;
        private Button bt_c;
        private Button bt_x;
        private Button bt_z;
        private Button bt_m;
        private Button bt_n;
        private Label lbl_1;
        private Label lbl_2;
        private Label lbl_5;
        private Label lbl_4;
        private Label lbl_3;
    }
}